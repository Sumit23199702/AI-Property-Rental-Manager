const RentalRequestModel = require("../models/rentalRequestModel");
const PropertyModel = require("../models/PropertyModel");
const { isValid, isValidObjectId } = require("../utils/validator");

// Send Rental Request (User)

// Get My Rental Request (User)

// Track Rental Request (User)

// Get Request For My Properties (Owner)

// Approve Rental Request (Owner)

// Reject Rental Request (Owner)
